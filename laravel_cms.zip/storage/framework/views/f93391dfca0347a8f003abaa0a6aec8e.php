<div class="container">
    <?php if(session('success')): ?>
        <div class="alert alert-success mt-2"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('songlist.store', $slug->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="song_id">Pilih Lagu:</label>
            <select name="song_id" id="song_id" class="form-control">
                <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($song->id); ?>"><?php echo e($song->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Tambahkan Lagu</button>
    </form>

    <hr>

    <h4>Daftar Lagu yang Dipilih:</h4>
    <ul class="list-group">
        <?php $__currentLoopData = $selectedSong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $songId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $song = $songs->firstWhere('id', $songId); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <?php echo e($song->title); ?>

                <form action="<?php echo e(route('songlist.destroy', $songId)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm">Hapus</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH /var/www/html/cms-fix/resources/views/slug/partials/song_list.blade.php ENDPATH**/ ?>