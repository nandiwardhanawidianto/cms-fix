<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Bank CMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0">🏦 Master Bank CMS</h3>
        <a href="<?php echo e(route('slug.index')); ?>" class="btn btn-secondary">⬅ Kembali ke Slug</a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5 class="mb-3">Tambah Bank Baru</h5>
            <form action="<?php echo e(route('banks.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="nama_bank" class="form-label">Nama Bank</label>
                        <input type="text" name="nama_bank" class="form-control" required>
                    </div>
                    <div class="col-md-5">
                        <label for="logo_bank" class="form-label">Logo Bank (opsional)</label>
                        <input type="file" name="logo_bank" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary w-100">Tambah</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Daftar Bank</strong>
        </div>
        <div class="card-body">
            <?php if($banks->count()): ?>
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Nama Bank</th>
                            <th>Logo</th>
                            <th width="120">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($bank->nama_bank); ?></td>
                                <td>
                                    <?php if($bank->logo_bank): ?>
                                        <img src="<?php echo e(asset('storage/'.$bank->logo_bank)); ?>" alt="Logo" width="60">
                                    <?php else: ?>
                                        <small>Tidak ada</small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('banks.destroy', $bank->id)); ?>" method="POST" onsubmit="return confirm('Hapus bank ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger w-100">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted">Belum ada data bank.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH /var/www/html/cms-fix/resources/views//slug/mastercms.blade.php ENDPATH**/ ?>