<div class="card mt-3">
    <div class="card-header">
        <h5>Galeri</h5>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('galeri.store', $slug_id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label class="form-label">Carousel Atas (max 5)</label>
                <input type="file" name="carousel_atas[]" multiple accept="image/*" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Carousel Bawah (max 5)</label>
                <input type="file" name="carousel_bawah[]" multiple accept="image/*" class="form-control">
            </div>

            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>

        <?php if(!empty($galeri)): ?>
            <hr>
            <h6>Preview Carousel Atas</h6>
            <div class="d-flex flex-wrap">
                <?php $__currentLoopData = json_decode($galeri->carousel_atas ?? '[]', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('storage/'.$img)); ?>" class="img-thumbnail m-1" width="120">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <h6 class="mt-3">Preview Carousel Bawah</h6>
            <div class="d-flex flex-wrap">
                <?php $__currentLoopData = json_decode($galeri->carousel_bawah ?? '[]', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('storage/'.$img)); ?>" class="img-thumbnail m-1" width="120">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH /var/www/html/cms-fix/resources/views/slug/partials/galeri.blade.php ENDPATH**/ ?>