<div class="card mt-3">
    <div class="card-header">
        <h5>💝 Love Gift</h5>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('lovegift.store', $slug_id)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div id="bank-wrapper">
                <?php
                    $count = isset($love_gifts) && count($love_gifts) > 0 ? count($love_gifts) : 1;
                ?>
                <?php for($i = 0; $i < $count; $i++): ?>
                    <?php $gift = $love_gifts[$i] ?? null; ?>
                    <div class="card mb-3 p-3 bank-item">
                        <h6>Bank <?php echo e($i + 1); ?></h6>

                        <div class="mb-2">
                            <label>Nama Bank</label>
                            <select name="bank_id[]" class="form-control" required>
                                <option value="">-- Pilih Bank --</option>
                                <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($bank->id); ?>"
                                        <?php echo e($gift && $gift->bank_id == $bank->id ? 'selected' : ''); ?>>
                                        <?php echo e($bank->nama_bank); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-2">
                            <label>No Rekening</label>
                            <input type="text" name="no_rekening[]" class="form-control"
                                   value="<?php echo e($gift->no_rekening ?? ''); ?>" required>
                        </div>

                        <div class="mb-2">
                            <label>Nama Pemilik</label>
                            <input type="text" name="pemilik_bank[]" class="form-control"
                                   value="<?php echo e($gift->pemilik_bank ?? ''); ?>" required>
                        </div>

                        
                        <?php if($gift && isset($gift->bank) && $gift->bank && $gift->bank->logo): ?>
                            <div class="mb-2">
                                <label>Logo Bank</label><br>
                                <img src="<?php echo e(asset('storage/'.$gift->bank->logo)); ?>" width="100" alt="Logo">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endfor; ?>
            </div>

            <button type="button" id="btnAddBank" class="btn btn-sm btn-secondary">+ Tambah Bank</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>

<script>
let maxBank = 3;
let bankWrapper = document.getElementById('bank-wrapper');
let btnAddBank = document.getElementById('btnAddBank');

btnAddBank.addEventListener('click', function () {
    let bankCount = bankWrapper.querySelectorAll('.bank-item').length;
    if (bankCount >= maxBank) {
        alert("Maksimal hanya 3 rekening bank!");
        return;
    }

    // Generate options dari server-side (Blade)
    let options = `<?php echo addslashes(
        collect($banks)->map(fn($b) => "<option value='{$b->id}'>{$b->nama_bank}</option>")->join('')
    ); ?>`;

    let newBank = document.createElement('div');
    newBank.classList.add('card','mb-3','p-3','bank-item');
    newBank.innerHTML = `
        <h6>Bank ${bankCount+1}</h6>
        <div class="mb-2">
            <label>Nama Bank</label>
            <select name="bank_id[]" class="form-control" required>
                <option value="">-- Pilih Bank --</option>
                ${options}
            </select>
        </div>
        <div class="mb-2">
            <label>No Rekening</label>
            <input type="text" name="no_rekening[]" class="form-control" required>
        </div>
        <div class="mb-2">
            <label>Nama Pemilik</label>
            <input type="text" name="pemilik_bank[]" class="form-control" required>
        </div>
    `;
    bankWrapper.appendChild(newBank);
});
</script>
<?php /**PATH /var/www/html/cms-fix/resources/views/slug/partials/lovegift.blade.php ENDPATH**/ ?>